public class Elbil extends Bil{
    private int batteriKapacitetKWH;
    private int maxKm;
    private int whPrKm;
    private double kmPrL;
    private double pris;

    public Elbil(int batteriKapacitetKWH, int maxKm, int whPrKm){
        this.batteriKapacitetKWH = batteriKapacitetKWH;
        this.maxKm = maxKm;
        this.whPrKm = whPrKm;

    }

    @Override
    public double beregnGroenEjerAfgift() {
        kmPrL = (whPrKm/91.25);
        kmPrL = 100/kmPrL;
        if (kmPrL > 20){
            pris = 330;

        }else  if (kmPrL > 15){
            pris = 1050;

        }else if (kmPrL > 10){
            pris = 2340;

        }else if (kmPrL > 5){
            pris = 5500;
        }else{
            pris = 10470;
        }

        return pris;
    }

    public int getBatteriKapacitetKWH() {
        return batteriKapacitetKWH;
    }

    public void setBatteriKapacitetKWH(int batteriKapacitetKWH) {
        this.batteriKapacitetKWH = batteriKapacitetKWH;
    }

    public int getMaxKm() {
        return maxKm;
    }

    public void setMaxKm(int macKm) {
        this.maxKm = macKm;
    }

    public int getWhPrKm() {
        return whPrKm;
    }

    public void setWhPrKm(int whPrKm) {
        this.whPrKm = whPrKm;
    }

   @Override
    public String toString() {
        return "Elbil{" +
                "batteriKapacitetKWH=" + batteriKapacitetKWH +
                ", macKm=" + maxKm +
                ", whPrKm=" + whPrKm +
                '}';
    }
}
