public class Main {
    public static void main(String [] args) {
        Garage garage = new Garage("Bilpark");
        Benzinbil benzinbil = new Benzinbil(2, 30);
        Dieselbil dieselbil = new Dieselbil(true, 30);
        Elbil elbil = new Elbil(45,20, 20);
        garage.addCar(benzinbil);
        garage.addCar(dieselbil);
        garage.addCar(elbil);

        System.out.println(garage.toString());
        garage.beregnGroenAfgiftForBilpark();
    }
}
