public class Benzinbil extends Bil{
    private int oktAntal;
    private int kmPrL;
    private int pris = 0;

    public Benzinbil(int oktAntal, int kmPrL){
        this.oktAntal = oktAntal;
        this.kmPrL = kmPrL;


    }

    @Override
    public double beregnGroenEjerAfgift() {
        if (this.kmPrL > 20) {
            pris = 330;

        } else if (this.kmPrL > 15){
            pris = 1050;

        }else if (this.kmPrL > 10){
            pris = 2340;

        }else if (this.kmPrL > 5){
            pris = 5500;

        }else{
            pris = 10470;
        }
        return pris;
    }

    public int getOktAntal() {
        return oktAntal;
    }

    public void setOktAntal(int oktAntal) {
        this.oktAntal = oktAntal;
    }

    public int getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(int kmPrL) {
        this.kmPrL = kmPrL;
    }

    @Override
    public String toString() {
        return "Benzinbil{" +
                "oktAntal=" + oktAntal +
                ", kmPrL=" + kmPrL +
                '}';
    }
}
