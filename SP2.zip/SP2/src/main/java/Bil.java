abstract public class Bil {
    private int regNr;
    private String maerke;
    private String model;
    private int aargang;
    private int antalDoere;


    abstract public double beregnGroenEjerAfgift();

    public int getRegNr() {
        return regNr;
    }

    public void setRegNr(int regNr) {
        this.regNr = regNr;
    }

    public String getMaerke() {
        return maerke;
    }

    public void setMaerke(String maerke) {
        this.maerke = maerke;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getAargang() {
        return aargang;
    }

    public void setAargang(int årgang) {
        this.aargang = aargang;
    }

    public int getAntalDoere() {
        return antalDoere;
    }

    public void setAntalDoere(int antalDoere) {
        this.antalDoere = antalDoere;
    }
}
