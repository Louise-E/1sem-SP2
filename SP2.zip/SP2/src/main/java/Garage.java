import java.util.ArrayList;

public class Garage {
    private String name;
    private ArrayList<Bil> garage = new ArrayList<Bil>();
    private double samletPris;

    public Garage(String name){
        this.name = name;
    }
    public void addCar(Bil bil){
        garage.add(bil);
    }
    public void beregnGroenAfgiftForBilpark(){
        for(Bil alleBiler: garage){
            samletPris += alleBiler.beregnGroenEjerAfgift();

        }
        System.out.println("samlet afgift " + samletPris);
    }

    @Override
    public String toString() {
        return "Velkommen til " + name + "indeholder " + garage.toString();
    }
}
