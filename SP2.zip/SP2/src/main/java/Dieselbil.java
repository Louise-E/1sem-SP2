public class Dieselbil extends Bil{
    private boolean harPartikelFilter;
    private int kmPrL;
    private int pris;

    @Override
    public double beregnGroenEjerAfgift() {
        if (this.kmPrL > 20) {
            pris = 330 + 130;

        } else if (this.kmPrL > 15){
            pris = 1050 + 1390;

        }else if (this.kmPrL > 10){
            pris = 2340 + 1850;

        }else if (this.kmPrL > 5){
            pris = 5500 + 2770;

        }else{
            pris = 10470 + 15260;
        }

        if (harPartikelFilter != true){
            pris += 1000;
        }

        return pris;

    }


    public Dieselbil(boolean harPartikelFilter, int kmPrL){
        this.harPartikelFilter = harPartikelFilter;
        this.kmPrL = kmPrL;
    }

    public boolean isHarPartikelFilter() {
        return harPartikelFilter;
    }

    public void setHarPartikelFilter(boolean harPartikelFilter) {
        this.harPartikelFilter = harPartikelFilter;
    }

    public int getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(int kmPrL) {
        this.kmPrL = kmPrL;
    }

    @Override
    public String toString() {
        return "Dieselbil{" +
                "harPartikelFilter=" + harPartikelFilter +
                ", kmPrL=" + kmPrL +
                '}';
    }
}
